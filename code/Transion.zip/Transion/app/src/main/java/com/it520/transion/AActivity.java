package com.it520.transion;

import android.annotation.TargetApi;
import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.transition.Slide;
import android.view.Gravity;
import android.view.View;

/**
 * Created by kay on 16/9/21.
 */
public class AActivity extends AppCompatActivity {
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.GRAY));

        setContentView(R.layout.activity_a);
        Slide slide = new Slide(Gravity.BOTTOM);

        Slide slide_top = new Slide(Gravity.RIGHT);


        getWindow().setExitTransition(slide_top);






    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public  void goTo(View view ){
        Intent intent = new Intent();
        intent.setClass(this,BActivity.class);


        startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
    }
}
