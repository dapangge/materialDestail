package com.it520.transion;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.transition.Slide;
import android.util.Log;
import android.view.Gravity;

/**
 * Created by kay on 16/9/21.
 */
public class BActivity extends AppCompatActivity {
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        Slide slideE = new Slide(Gravity.BOTTOM);

        getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLUE));
        getWindow().setEnterTransition(slideE );




        setContentView(R.layout.activity_b);


    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        boolean  isShow =  getWindow().getAllowReturnTransitionOverlap();
        Log.i("hked","isShow = "+isShow);
    }
}
