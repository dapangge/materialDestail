package com.it520.transion;

import android.app.Activity;
import android.os.Bundle;
import android.transition.Explode;
import android.view.Window;
import android.widget.ImageView;

/**
 * Created by kay on 16/8/31.
 */
public class DetailtraActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        getWindow().setEnterTransition(new Explode());
        setContentView(R.layout.activity_detailtra);
        int index = getIntent().getIntExtra("index",0);
        int[] src = new int[]{R.drawable.a1,R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,R.drawable.a6,R.drawable.a7,R.drawable.a8};
        ImageView icon = (ImageView) findViewById(R.id.icon);

        icon.setBackgroundResource(src[index]);
    }
}
