package com.it520.transion;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

/**
 * Created by kay on 16/9/13.
 */
public class EightActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eight);
//        ArrayList<String> all = new ArrayList<>();
//        String content = getString(R.string.content);
//
//        for(int i = 0 ;i<50;i++){
//            all.add(i+" "+content);
//        }
//        ListView list = (ListView) findViewById(R.id.listView);
//
//        MyAdapter adapter = new MyAdapter(all,this);
//        list.setAdapter(adapter);


        Toolbar tool = (Toolbar) findViewById(R.id.tool);
        tool.setTitle("huangkai");
        tool.setLogo(R.drawable.ic_brightness_medium_white_36dp);

    }
}
