package com.it520.transion;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by kay on 16/9/15.
 */
public class ElevenActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eleven);
    }
}
