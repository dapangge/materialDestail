package com.it520.transion;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.transition.Explode;
import android.view.View;
import android.view.Window;

/**
 * Created by kay on 17/2/17.
 */

public class ExploseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //判断系统的版本
        if(Build.VERSION.SDK_INT>=21){
            Explode explode = new Explode();
            getWindow().setExitTransition(explode);
            getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        }

        setContentView(R.layout.activity_explose);
    }


    public void click(View view){
        Intent intent  = new Intent();
        intent.setClass(ExploseActivity.this,DetailtraActivity.class);
        if(Build.VERSION.SDK_INT>=21){
            //使用ActivityOptions产生过场的动画
            startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(this).toBundle());
        }
        else{
            startActivity(intent);
        }
    }
}
