package com.it520.transion;

import android.animation.Animator;
import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;

/**
 * Created by kay on 16/9/9.
 */
public class FiveActivity extends Activity {
    FrameLayout circle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_five);
        //生成动画的控件
        circle = (FrameLayout) findViewById(R.id.circle);
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void click(View view)
    {
        //在指定控件的指定位置生成圆形动画
        Animator anim = ViewAnimationUtils.createCircularReveal(circle, 200, 200, 0, 300);
        //开始控件是没有背景的，后面设置背景
        circle.setBackgroundColor(Color.RED);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }
}
