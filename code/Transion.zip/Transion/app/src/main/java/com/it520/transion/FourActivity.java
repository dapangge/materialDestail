package com.it520.transion;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Scene;
import android.transition.TransitionInflater;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * Created by kay on 16/9/7.
 */
public class FourActivity extends Activity implements View.OnClickListener{
    Button b1,b2,b3,b4;
    LinearLayout root;
    FrameLayout scent_root;

    Scene one;
    Scene two;
    Scene three;
    Scene four;

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_four);
        b1 = (Button) findViewById(R.id.b1);
        b1.setOnClickListener(this);
        b2 = (Button) findViewById(R.id.b2);
        b2.setOnClickListener(this);
        b3 = (Button) findViewById(R.id.b3);
        b3.setOnClickListener(this);
        b4 = (Button) findViewById(R.id.b4);
        b4.setOnClickListener(this);
        root = (LinearLayout) findViewById(R.id.root);
        root.setOnClickListener(this);
        scent_root = (FrameLayout) findViewById(R.id.scent_outer);

        //getSceneForLayout(ViewGroup sceneRoot, int layoutId, Context context)
        //sceneRoot 产生变化的父布局
        //layoutId 将某个布局文件的转化到父控件内
        //context 不解释
        Scene sceneone =  Scene.getSceneForLayout(scent_root,R.layout.scence_n,this);
        //执行这个场景操作
        TransitionManager.go(sceneone);


        loadAllScene();
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onClick(View v) {
//        Explode explode = new Explode();
//        explode.setDuration(2000);
//        TransitionManager.beginDelayedTransition(root,explode);

      switch (v.getId()){
          case R.id.b1:
              TransitionManager.go(one, new ChangeBounds());
              break;
          case R.id.b2:
              TransitionManager.go(two, TransitionInflater.from(FourActivity.this).
                      inflateTransition(R.transition.slide_change));
              break;
          case R.id.b3:
              TransitionManager.go(three, new ChangeBounds());
              break;
          case R.id.b4:
              TransitionManager.go(four, new ChangeBounds());


//          case R.id.b1:
//              TransitionManager.go(one);
//              break;
//          case R.id.b2:
//              TransitionManager.go(two);
//              break;
//          case R.id.b3:
//              TransitionManager.go(three);
//              break;
//          case R.id.b4:
//              TransitionManager.go(four);
              break;
      }

    }


    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void loadAllScene(){
        //接着我们生成四个场景
        one  = Scene.getSceneForLayout(scent_root,R.layout.scence_one,this);
        two  = Scene.getSceneForLayout(scent_root,R.layout.scence_two,this);
        three  = Scene.getSceneForLayout(scent_root,R.layout.scence_three,this);
        four  = Scene.getSceneForLayout(scent_root,R.layout.scence_four,this);

    }
    public void hideView(View view){
       view.setVisibility(View.GONE);
    }
}
