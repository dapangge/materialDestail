package com.it520.transion;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by kay on 16/8/31.
 */
public class ImageAdapter extends RecyclerView.Adapter<ImageViewHolder> {

    int[] img;
    Context context;
    onClickImageListener listener;
    LayoutInflater inflater;
    public void setListener(onClickImageListener listener) {
        this.listener = listener;
    }

    public ImageAdapter(int[] img, Context context) {
        this.img = img;

        inflater = LayoutInflater.from(context);
    }

    @Override
    public ImageViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = inflater.inflate(R.layout.item_view,viewGroup,false);
        ImageViewHolder holder = new ImageViewHolder(view);
        return holder;

    }

    @Override
    public void onBindViewHolder(final ImageViewHolder viewHolder, int i) {
        viewHolder.itemView.setBackgroundResource(img[i]);
        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(listener!=null){
                    int index = viewHolder.getAdapterPosition();
                    listener.onClickImg(viewHolder.imageView,index,index);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return img.length;
    }
}
class ImageViewHolder extends RecyclerView.ViewHolder{
    ImageView imageView;
    public ImageViewHolder(View itemView) {
        super(itemView);
        imageView = (ImageView) itemView.findViewById(R.id.icon);
    }
}
