package com.it520.transion;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by kay on 16/9/9.
 */
public class LinAdapter extends RecyclerView.Adapter<LinAdapter.ViewHodler> {
    ArrayList<String> titles;
    LayoutInflater inflater;

    public LinAdapter(ArrayList<String> titles, Context context) {
        this.titles = titles;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHodler onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view =  inflater.inflate(R.layout.item_t,viewGroup,false);

        return new ViewHodler(view);
    }

    @Override
    public void onBindViewHolder(ViewHodler viewHodler, int i) {
        Log.i("hked","i = "+i );
        viewHodler.textView.setText(titles.get(i));
        setAnimation(viewHodler.itemView,viewHodler.getAdapterPosition());
    }

    @Override
    public int getItemCount() {
        return titles.size();
    }

    private int lastPosition = -1;

    private void setAnimation(View viewToAnimate, int position) {
        // If the bound view wasn't previously displayed on screen, it's animated
        if (position > lastPosition) {
            TranslateAnimation anim = new TranslateAnimation(0,0,20,0);
            anim.setDuration(new Random().nextInt(501));//to make duration random number between [0,501)
            viewToAnimate.startAnimation(anim);
            lastPosition = position;
        }else{
            TranslateAnimation anim = new TranslateAnimation(0,0,-20,0);
            anim.setDuration(new Random().nextInt(501));//to make duration random number between [0,501)
            viewToAnimate.startAnimation(anim);
            lastPosition = position;
        }
    }


    class ViewHodler extends RecyclerView.ViewHolder{
       TextView textView;
        public ViewHodler(View itemView) {
            super(itemView);
            textView = (TextView) itemView.findViewById(R.id.title);
        }
    }
}
