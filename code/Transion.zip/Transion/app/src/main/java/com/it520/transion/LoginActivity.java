package com.it520.transion;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;

/**
 * Created by kay on 16/9/30.
 */
public class LoginActivity extends Activity implements View.OnClickListener{
    FloatingActionButton fab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(this);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.fab:
                getWindow().setExitTransition(null);
                getWindow().setEnterTransition(null);

                ActivityOptions option =   ActivityOptions.makeSceneTransitionAnimation(this,fab,fab.getTransitionName());
                Intent intent = new Intent();
                intent.setClass(this,RegActivity.class);
                startActivity(intent,option.toBundle());
                break;
        }
    }
}
