package com.it520.transion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.graphics.Palette;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener {

    ViewPager viewPager;
    int[] darwables;
    ArrayList<ImageView> imageViews;
    pagerAdper adper;
    View title;
    HandlerThread colorThread ;
    Handler colorHandler;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        darwables = new int[]{R.drawable.a, R.drawable.b, R.drawable.c, R.drawable.d};

        title = findViewById(R.id.title);

        viewPager = (ViewPager) findViewById(R.id.viewPager);
        btn = (Button) findViewById(R.id.btn);
        imageViews = new ArrayList<>();
        for (int i = 0; i < darwables.length; i++) {
            ImageView image = new ImageView(this);
            image.setBackgroundResource(darwables[i]);
            imageViews.add(image);

        }
        adper = new pagerAdper(imageViews, this);
        viewPager.setAdapter(adper);

        viewPager.addOnPageChangeListener(this);

        colorThread = new HandlerThread("change_color");
        colorThread.start();
        colorHandler = new Handler(colorThread.getLooper()){
            @Override
            public void handleMessage(Message msg) {
               long id =  Thread.currentThread().getId();
                Log.i("id","id = "+id);
                int indedx = msg.what;
                setColor(indedx);
            }
        };

        colorHandler.sendEmptyMessage(0);

        long id =  Thread.currentThread().getId();
        Log.i("id","ui id = "+id);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        colorThread.quit();
    }

    public void setColor(int index) {
       btn.setText("abc");
        Bitmap bm = BitmapFactory.decodeResource(getResources(), darwables[index]);
        Palette.from(bm).generate(new Palette.PaletteAsyncListener() {

            @Override
            public void onGenerated(Palette palette) {
                if (palette.getDarkMutedSwatch() != null) {

                    int color = palette.getDarkMutedSwatch().getRgb();
                    title.setBackgroundColor(color);
                    Window window = getWindow();
                    window.setStatusBarColor(color);
                    window.setNavigationBarColor(color);

                }else if(palette.getLightVibrantSwatch() != null){

                    int color = palette.getLightVibrantSwatch().getRgb();
                    title.setBackgroundColor(color);
                    Window window = getWindow();
                    window.setStatusBarColor(color);
                    window.setNavigationBarColor(color);
                }else{

                }

            }
        });
    }

    public void gotoSec(View view){
        colorHandler.sendEmptyMessage(2);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        colorHandler.sendEmptyMessage(position);

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    class pagerAdper extends PagerAdapter {
        ArrayList<ImageView> views;
        Context context;
        public pagerAdper(ArrayList<ImageView> views, Context context) {
            this.views = views;
            this.context = context;
        }

        @Override
        public int getCount() {
            return views.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            ImageView imageView = views.get(position);
            container.addView(imageView);
            return imageView;

        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((ImageView) object);
        }
    }
}
