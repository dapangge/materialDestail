package com.it520.transion;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by kay on 16/9/13.
 */
public class MyAdapter2 extends BaseAdapter {
    ArrayList<String> date;
    Context context ;

    public MyAdapter2(ArrayList<String> date, Context context) {
        this.date = date;
        this.context = context;
    }

    @Override
    public int getCount() {
        return date.size();
    }

    @Override
    public Object getItem(int position) {
        return date.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context,R.layout.item_no_scroll,null);
        TextView textView = (TextView) view.findViewById(R.id.title);
        textView.setText(date.get(position));
        return view;
    }
}
