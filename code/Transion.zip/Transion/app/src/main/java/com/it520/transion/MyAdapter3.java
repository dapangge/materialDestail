package com.it520.transion;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

/**
 * Created by kay on 16/9/13.
 */
public class MyAdapter3 extends BaseAdapter {
    ArrayList<String> date;
    LayoutInflater inflater;

    public MyAdapter3(ArrayList<String> date, Context context) {
        this.date = date;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return date.size();
    }

    @Override
    public Object getItem(int position) {
        return date.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = inflater.inflate(R.layout.item_click,parent,false);
        //TextView textView = (TextView) view.findViewById(R.id.title);
        //textView.setText(date.get(position));
        return view;
    }
}
