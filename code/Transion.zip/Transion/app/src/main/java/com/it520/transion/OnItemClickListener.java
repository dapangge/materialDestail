package com.it520.transion;

/**
 * Created by kay on 17/2/16.
 */

public interface OnItemClickListener {
    void clickedItem();
}
