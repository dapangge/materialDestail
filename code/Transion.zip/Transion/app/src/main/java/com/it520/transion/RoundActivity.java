package com.it520.transion;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Outline;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityOptionsCompat;
import android.transition.Slide;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.ImageView;

import static com.it520.transion.R.id.fab;

/**
 * Created by kay on 17/2/20.
 */

public class RoundActivity extends Activity {

    ImageView image;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //做好版本判断
        if (Build.VERSION.SDK_INT >= 21) {
            //允许转场动画
            getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);
            //滑动动画，划出左边，时长500毫秒
            Slide slideTransition = new Slide();
            slideTransition.setSlideEdge(Gravity.LEFT);
            slideTransition.setDuration(500);
            //为这个activity设置退出动画
            getWindow().setExitTransition(slideTransition);
        }

        setContentView(R.layout.activity_round);
        image = (ImageView) findViewById(R.id.img);
        image.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        findViewById(R.id.other2).setTranslationZ(100);
                        break;
                    case MotionEvent.ACTION_UP:
                        findViewById(R.id.other2).setTranslationZ(0);
                        break;
                }
                return true;
            }
        });


        ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {

                outline.setOval(0, 0, 200, 200);
            }
        };
        image.setOutlineProvider(viewOutlineProvider);
    }


    public void click(View view) {

        Intent intent = new Intent();
        intent.setClass(RoundActivity.this, RoundDetailActivity.class);
        //生成同元素过渡动画
        ActivityOptionsCompat compat = ActivityOptionsCompat.makeSceneTransitionAnimation(
                this, image, getString(R.string.name));
        if (Build.VERSION.SDK_INT >= 16) {
            startActivity(intent, compat.toBundle());
        }
        else{
            startActivity(intent);
        }
    }

    public void click2(View view){

    }
}
