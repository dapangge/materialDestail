package com.it520.transion;

import android.animation.Animator;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.transition.ChangeBounds;
import android.transition.Transition;
import android.util.Log;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageView;

import static com.it520.transion.R.id.toolBar;
import static com.it520.transion.R.styleable.show;

/**
 * Created by kay on 17/2/20.
 */

public class RoundDetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 21) {
            ChangeBounds changeBounds = new ChangeBounds();
            //监听动画的执行
            changeBounds.addListener(new Transition.TransitionListener() {

                @Override
                public void onTransitionStart(Transition transition) {


                }

                @Override
                public void onTransitionEnd(Transition transition) {

                    findViewById(R.id.img).setVisibility(View.GONE);
                    showToolBar();
                }

                @Override
                public void onTransitionCancel(Transition transition) {

                }

                @Override
                public void onTransitionPause(Transition transition) {

                }

                @Override
                public void onTransitionResume(Transition transition) {

                }
            });
            getWindow().requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS);
            getWindow().setSharedElementEnterTransition(changeBounds);
        }
        setContentView(R.layout.activity_round_detail);


    }



    private void showToolBar() {

        Toolbar toolBar = (Toolbar) findViewById(R.id.toolBar);
        //计算tooLBar的中心点
        int cx = (toolBar.getLeft() + toolBar.getRight()) / 2;
        int cy = (toolBar.getTop() + toolBar.getBottom()) / 2;
        //计算波纹动画的最终的半径，这里的算法是比较宽度和高度,选最大那个
        int finalRadius = Math.max(toolBar.getWidth(), toolBar.getHeight());

        //生成波纹动画
        Animator anim = ViewAnimationUtils.createCircularReveal(toolBar, cx, cy, 0, finalRadius);
        toolBar.setBackgroundColor(getResources().getColor(R.color.blue));
        toolBar.setVisibility(View.VISIBLE);
        anim.setDuration(500);
        anim.setInterpolator(new AccelerateInterpolator());
        anim.start();
    }
}
