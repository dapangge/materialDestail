package com.it520.transion;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

/**
 * Created by kay on 16/8/31.
 */
public class SecActivity extends Activity implements onClickImageListener{
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);
        recyclerView = (RecyclerView) findViewById(R.id.rec);
        int[] src = new int[]{R.drawable.a1,R.drawable.a2,R.drawable.a3,R.drawable.a4,R.drawable.a5,R.drawable.a6,R.drawable.a7,R.drawable.a8};
        ImageAdapter adapter = new ImageAdapter(src,this);
        GridLayoutManager layout = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layout);
        recyclerView.setAdapter(adapter);
        adapter.setListener(this);
    }

    @Override
    public void onClickImg(ImageView imageView, int index, int src) {
        gotoDetailActivity(imageView,index);
    }

    public void gotoDetailActivity(View view , int index){

        //获取被点击控件的坐标
        int []size = new int[2];
        view.getLocationOnScreen(size);


        ActivityOptionsCompat options =
                ActivityOptionsCompat.makeScaleUpAnimation(view, //The View that the new activity is animating from
                        (int)view.getWidth()/2, (int)view.getHeight()/2, //拉伸开始的坐标
                        0, 0);//拉伸开始的区域大小，这里用（0，0）表示从无到全屏
        Intent intent = new Intent(this,DetailActivity.class);
        intent.putExtra("index",index);
        ActivityCompat.startActivity(this, intent, options.toBundle());

    }


    public void gotoDetail(View view ){
        ActivityOptionsCompat options =
                ActivityOptionsCompat.makeScaleUpAnimation(view, //The View that the new activity is animating from
                        (int)view.getWidth()/2, (int)view.getHeight()/2, //拉伸开始的坐标
                        0, 0);//拉伸开始的区域大小，这里用（0，0）表示从无到全屏
        Intent intent = new Intent(this,DetailActivity.class);
        intent.putExtra("index",0);
        ActivityCompat.startActivity(this, intent, options.toBundle());

    }
}
