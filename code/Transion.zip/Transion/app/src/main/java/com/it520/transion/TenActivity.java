package com.it520.transion;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * Created by kay on 16/9/14.
 */
public class TenActivity extends Activity {

    MyAdapter2 adapter;
    ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ten);
        ArrayList<String> name = new ArrayList<>();
        for(int i = 0 ;i<30;i++){
            name.add("第"+i+"条数据");
        }

        adapter = new MyAdapter2(name, this);
        list = (ListView) findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i("hked","click");

                Snackbar snack = Snackbar.make(findViewById(R.id.content), "点击了"+position+"位置", Snackbar.LENGTH_SHORT);
                snack.setAction("show next", new View.OnClickListener(){

                    @Override
                    public void onClick(View v) {

                    }
                });
                //修改SnackBar的UI
                View s_view = snack.getView();
                TextView tv = (TextView) s_view.findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.WHITE);

                snack.show();

            }
        });
    }
}
