package com.it520.transion;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.transition.Explode;
import android.transition.TransitionManager;

import java.util.ArrayList;

/**
 * Created by kay on 17/2/16.
 */

public class TestExploe extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<String>titles;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_explose);
        recyclerView = (RecyclerView) findViewById(R.id.recyle);

        titles = new ArrayList<>();

        for(int i =0;i<100;i++){
          titles.add(String.valueOf(i));
        }


        RecyAdapter adapter = new RecyAdapter(titles);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this,4));


        adapter.setListener(new OnItemClickListener() {
            @Override
            public void clickedItem() {
                Explode explode = new Explode();
                explode.setDuration(10000);
                //监控RecyleView
                TransitionManager.beginDelayedTransition(recyclerView,explode);
                //将RecycleView的内容制空
                recyclerView.setAdapter(null);

            }
        });


    }
}
