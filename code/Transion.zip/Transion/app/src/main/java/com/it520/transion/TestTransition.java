package com.it520.transion;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.transition.Slide;
import android.transition.TransitionManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by kay on 17/2/16.
 */

public class TestTransition extends AppCompatActivity {

    Button button;
    TextView text;
    ViewGroup root;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_transition);
        button = (Button) findViewById(R.id.button);
        text = (TextView) findViewById(R.id.text);

        root = (ViewGroup) findViewById(R.id.root);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int vis = text.getVisibility();
//                boolean isShow = vis==View.VISIBLE;
//                //开始监控父控件
//                TransitionManager.beginDelayedTransition(root);
//                //将文本显示或者隐藏
//                text.setVisibility(!isShow?View.VISIBLE:View.GONE);
//            }
//        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int vis = text.getVisibility();
                boolean isShow = vis==View.VISIBLE;
                TransitionManager.beginDelayedTransition(root,new Slide(Gravity.RIGHT));
                text.setVisibility(!isShow?View.VISIBLE:View.GONE);
            }
        });
    }
}
