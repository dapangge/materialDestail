package com.it520.transion;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.Window;

/**
 * Created by kay on 16/8/31.
 */
public class ThirdActivity extends Activity  {
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //获取当前的手机的系统的版本号
        int sdk_version =  android.os.Build.VERSION.SDK_INT;
        //如果手机是21版本以上的，才支持过渡动画
        if(sdk_version >= 21){
            getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        }


        setContentView(R.layout.activity_thd);


    }





    //1个共享动画跳转
    public void gotoDetail(View view ){
        ActivityOptionsCompat options =
                ActivityOptionsCompat.makeSceneTransitionAnimation(this,findViewById(R.id.img),getString(R.string.transion_name));

        Intent intent = new Intent(this,DetailtraActivity.class);
        intent.putExtra("index",0);
        ActivityCompat.startActivity(this, intent, options.toBundle());

    }

    //多个共享动画跳转
    public void gotoDetail2(View view){
        ActivityOptionsCompat options =
                ActivityOptionsCompat.makeSceneTransitionAnimation(this,Pair.create(findViewById(R.id.img),getString(R.string.transion_name)),
                        Pair.create(findViewById(R.id.img2),getString(R.string.transion_name2)));

        Intent intent = new Intent(this,DetailtraActivity.class);
        intent.putExtra("index",0);
        ActivityCompat.startActivity(this, intent, options.toBundle());
    }

    public void gotoDetail3(View view){

        Bitmap bitmap =  BitmapFactory.decodeResource(getResources(),R.drawable.a3);
        //最后两个参数是这个控件的偏移量
        ActivityOptionsCompat options =
                ActivityOptionsCompat.makeThumbnailScaleUpAnimation(view,bitmap,-500,0);

        Intent intent = new Intent(this,DetailtraActivity.class);
        intent.putExtra("index",0);
        ActivityCompat.startActivity(this, intent, options.toBundle());
    }
}
