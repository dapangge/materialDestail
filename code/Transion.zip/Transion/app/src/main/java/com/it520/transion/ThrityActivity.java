package com.it520.transion;

import android.app.Activity;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.view.View;

/**
 * Created by kay on 16/9/15.
 */
public class ThrityActivity extends Activity {
    TextInputLayout one,two;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thirty);
        one = (TextInputLayout) findViewById(R.id.one);

    }

    public void showError(View view ){
        two = (TextInputLayout) findViewById(R.id.two);
        two.setError("fail");
    }

    public void clean(View view ){
        two.setError("");
    }
}
