package com.it520.transion;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Created by kay on 16/9/20.
 */
public class TransionActivity extends Activity {
Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transion);
        btn = (Button) findViewById(R.id.btn);

    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void show(View view){
      TransitionManager.beginDelayedTransition((LinearLayout) findViewById(R.id.parent),new Fade());
//      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) btn.getLayoutParams();
//        layoutParams.setMargins(0,500,0,0);
//        layoutParams.width = btn.getWidth()*2;
//        layoutParams.height = btn.getHeight()*2;
//        btn.setLayoutParams(layoutParams);
        btn.setVisibility(View.GONE);
    }
}
