package com.it520.transion;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by kay on 16/9/12.
 */
public class TwifActivity extends Activity {
ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twife);
        list = (ListView) findViewById(R.id.listView);
        ArrayList<String> date = new ArrayList<>();
        for(int i =0;i<50;i++){
            date.add("第"+i+"条数据");
        }
        MyAdapter3 adapter3 = new MyAdapter3(date,this);
        list.setAdapter(adapter3);
    }
}
