package com.it520.transion;

import android.widget.ImageView;

/**
 * Created by kay on 16/8/31.
 */
public interface onClickImageListener {
    public void onClickImg(ImageView image,int index, int src);
}
